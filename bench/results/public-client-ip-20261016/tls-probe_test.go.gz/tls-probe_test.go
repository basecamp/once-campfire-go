package web

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/basecamp/once-campfire-go/internal/database"
	"github.com/basecamp/once-campfire-go/internal/front"
	"github.com/basecamp/once-campfire-go/internal/rails"
	"golang.org/x/crypto/bcrypt"
)

func TestAuditPublicTLSApplicationTrustBoundary(t *testing.T) {
	app, _, _, owner := testApp(t)
	app.Secure = true
	digest, err := bcrypt.GenerateFromPassword([]byte("tls-test-password"), bcrypt.MinCost)
	if err != nil { t.Fatal(err) }; password := string(digest)
	if _, err = app.DB.UpdateUser(context.Background(), owner.ID, owner.ID, database.UserChanges{Password:&password}); err != nil { t.Fatal(err) }
	reserve := func() int { l,e := net.Listen("tcp","127.0.0.1:0");if e!=nil {t.Fatal(e)}; p:=l.Addr().(*net.TCPAddr).Port;l.Close();return p }
	c := front.FromLookup(func(string)(string,bool){return "",false})
	c.HTTPPort,c.HTTPSPort=reserve(),reserve();c.TargetPort=c.HTTPPort;c.Domains=[]string{"example.com"};c.ForwardHeaders=false;c.LogRequests=false;c.StoragePath=t.TempDir();c.ACMEDirectory="http://127.0.0.1:1/unreachable"
	fixtures := "../../reference/crates/campfire/src/integrations/testdata/tls/"
	key,err:=os.ReadFile(fixtures+"server.key");if err!=nil {t.Fatal(err)}
	cert,err:=os.ReadFile(fixtures+"server.pem");if err!=nil {t.Fatal(err)}
	if err=os.WriteFile(filepath.Join(c.StoragePath,"example.com"),append(key,cert...),0600);err!=nil {t.Fatal(err)}
	ca,err:=os.ReadFile(fixtures+"ca.pem");if err!=nil {t.Fatal(err)}
	roots:=x509.NewCertPool();if !roots.AppendCertsFromPEM(ca){t.Fatal("test CA unavailable")}
	ctx,cancel:=context.WithCancel(context.Background());done:=make(chan error,1);go func(){done<-front.Serve(ctx,c,app)}()
	transport:=&http.Transport{TLSClientConfig:&tls.Config{RootCAs:roots},ForceAttemptHTTP2:true,DialContext:func(ctx context.Context, network,address string)(net.Conn,error){_,port,_:=net.SplitHostPort(address);return (&net.Dialer{}).DialContext(ctx,network,net.JoinHostPort("127.0.0.1",port))}}
	client:=&http.Client{Transport:transport,Timeout:5*time.Second,CheckRedirect:func(*http.Request,[]*http.Request)error{return http.ErrUseLastResponse}}
	t.Cleanup(func(){client.CloseIdleConnections();cancel();select{case err:=<-done:if err!=nil{t.Error(err)};case<-time.After(7*time.Second):t.Error("public TLS listener did not stop")}})
	base:=fmt.Sprintf("https://example.com:%d",c.HTTPSPort)
	deadline:=time.Now().Add(3*time.Second)
	for {r,e:=client.Get(base+"/up");if e==nil{io.Copy(io.Discard,r.Body);r.Body.Close();if r.StatusCode!=200{t.Fatal(r.Status)};break};if time.Now().After(deadline){t.Fatal(e)};time.Sleep(10*time.Millisecond)}
	fetch:=func(method,path,origin,body string)*http.Response{t.Helper();r,e:=http.NewRequest(method,base+path,strings.NewReader(body));if e!=nil{t.Fatal(e)};r.Header.Set("Content-Type","application/x-www-form-urlencoded");r.Header.Set("Origin",origin);r.Header.Set("Sec-Fetch-Site","same-origin");r.Header.Set("Client-IP","127.0.0.1, 198.51.100.20");r.Header.Set("Forwarded",`for=198.51.100.20;proto=http;host=evil.test`);r.Header.Set("X-Forwarded-Host","evil.test");r.Header.Set("X-Forwarded-Proto","http");r.Header.Set("X-Forwarded-Scheme","http");response,e:=client.Do(r);if e!=nil{t.Fatal(e)};io.Copy(io.Discard,response.Body);response.Body.Close();return response}
	r:=fetch("GET","/rooms/1",base,"");if r.StatusCode!=302||r.Header.Get("Location")!=base+"/session/new"{t.Fatal("spoofed origin/redirect",r.StatusCode,r.Header.Get("Location"))};if r.ProtoMajor!=2{t.Fatal("TLS probe did not use HTTP2")}
	r=fetch("POST","/session","https://evil.test","email_address=owner%40test&password=tls-test-password");if r.StatusCode!=422{t.Fatal("cross-origin TLS login allowed",r.StatusCode)}
	r=fetch("POST","/session",base,url.Values{"email_address":{owner.Email},"password":{"tls-test-password"}}.Encode());if r.StatusCode!=302{t.Fatal("same-origin TLS login",r.StatusCode)}
	var token string
	for _,cookie:=range r.Cookies(){if cookie.Name=="session_token"{if !cookie.Secure||!cookie.HttpOnly||cookie.SameSite!=http.SameSiteLaxMode{t.Fatal("TLS authentication cookie policy")};if e:=app.Secrets.VerifyCookie(cookie.Name,rails.UnescapeCookie(cookie.Value),app.DB.Now(),&token);e!=nil{t.Fatal(e)}}}
	if token==""{t.Fatal("TLS login did not issue authentication")}
	var ip string;if err=app.DB.Read.QueryRow("SELECT ip_address FROM sessions WHERE token=?",token).Scan(&ip);err!=nil||ip!="127.0.0.1"{t.Fatal("TLS session accepted spoofed client IP",ip,err)}
}
