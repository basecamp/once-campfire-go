package application

// Temporary diagnostic input; removed before delivery.
import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/basecamp/once-campfire-go/internal/database"
	"github.com/basecamp/once-campfire-go/internal/presentation"
	"github.com/basecamp/once-campfire-go/internal/rails"
)

func treeProbeBody(kind string, id int64, secrets *rails.Secrets) string {
	if kind == "paragraph" {
		return "<p>Ordinary message &amp; text</p>"
	}
	if kind == "dense" {
		token := secrets.SGID(fmt.Sprintf("gid://campfire/User/%d?expires_in", id), "attachable", time.Time{})
		return strings.Repeat(`<p>Hi <action-text-attachment sgid="`+token+`"></action-text-attachment></p>`, 20)
	}
	tag, n := "ol", 1000
	if kind == "short" {
		n = 20
	}
	if kind == "unordered" {
		tag = "ul"
	}
	var b strings.Builder
	b.WriteString("<" + tag + ">")
	for i := 1; i <= n; i++ {
		fmt.Fprintf(&b, "<li>Item %d</li>", i)
	}
	b.WriteString("</" + tag + ">")
	return b.String()
}

func BenchmarkBodyTreeProbe(b *testing.B) {
	for _, kind := range []string{"unordered", "ordered", "short", "paragraph", "dense"} {
		b.Run(kind, func(b *testing.B) {
			ctx := context.Background()
			db, err := database.Open(filepath.Join(b.TempDir(), "probe.sqlite3"), 4)
			if err != nil {
				b.Fatal(err)
			}
			defer db.Close()
			user, err := db.Setup(ctx, "Owner", "owner@test", "digest")
			if err != nil {
				b.Fatal(err)
			}
			rooms, err := db.Rooms(ctx, user.ID)
			if err != nil {
				b.Fatal(err)
			}
			secrets, err := rails.NewSecrets("tree-probe-only")
			if err != nil {
				b.Fatal(err)
			}
			body := treeProbeBody(kind, user.ID, secrets)
			commit, err := db.CreateMessage(ctx, user.ID, rooms[0].ID, database.MessageInput{Body: &body})
			if err != nil {
				b.Fatal(err)
			}
			renderer, err := presentation.NewRenderer(secrets)
			if err != nil {
				b.Fatal(err)
			}
			q := MessageQueries{DB: db, Presentation: renderer}
			facts := presentation.Facts{Host: "benchmark.invalid", Origin: "http://benchmark.invalid", Now: db.Now()}
			b.ReportAllocs()
			b.ResetTimer()
			for b.Loop() {
				result, err := q.APIRecord(ctx, facts, commit.Message)
				if err != nil {
					b.Fatal(err)
				}
				switch kind {
				case "ordered":
					if !strings.HasSuffix(result.Body.Plain, "1000. Item 1000") {
						b.Fatal("numbering changed")
					}
				case "short":
					if !strings.HasSuffix(result.Body.Plain, "20. Item 20") {
						b.Fatal("numbering changed")
					}
				case "unordered":
					if !strings.HasSuffix(result.Body.Plain, "• Item 1000") {
						b.Fatal("bullet changed")
					}
				case "dense":
					if strings.Count(result.Body.Plain, "@Owner") != 20 {
						b.Fatal("lost mention")
					}
				}
			}
		})
	}
}

func TestBuildTreeProbeFixtures(t *testing.T) {
	out := os.Getenv("PERF_TREE_OUT")
	if out == "" {
		return
	}
	raw, err := os.ReadFile(os.Getenv("PERF_TREE_LABELS"))
	if err != nil {
		t.Fatal(err)
	}
	var labels map[string]json.RawMessage
	if err = json.Unmarshal(raw, &labels); err != nil {
		t.Fatal(err)
	}
	var email string
	if err = json.Unmarshal(labels["emails.david"], &email); err != nil {
		t.Fatal(err)
	}
	secrets, err := rails.NewSecrets(os.Getenv("PERF_TREE_SECRET"))
	if err != nil {
		t.Fatal(err)
	}
	for _, kind := range []string{"unordered", "ordered", "short", "paragraph", "dense"} {
		dir := filepath.Join(out, kind)
		db, err := database.Open(filepath.Join(dir, "production.sqlite3"), 4)
		if err != nil {
			t.Fatal(err)
		}
		var viewer int64
		var viewerName string
		if err = db.Read.QueryRow("SELECT id,name FROM users WHERE email_address=?", email).Scan(&viewer, &viewerName); err != nil {
			t.Fatal(err)
		}
		db.Now = func() time.Time { return time.Date(2026, 10, 16, 12, 0, 0, 0, time.UTC) }
		name := sql.NullString{String: "Tree performance", Valid: true}
		room, err := db.CreateRoom(context.Background(), viewer, "Rooms::Open", &name, nil)
		if err != nil {
			t.Fatal(err)
		}
		body := treeProbeBody(kind, viewer, secrets)
		commit, err := db.CreateMessage(context.Background(), viewer, room.ID, database.MessageInput{Body: &body})
		if err != nil {
			t.Fatal(err)
		}
		if err = db.Close(); err != nil {
			t.Fatal(err)
		}
		raw, err = json.Marshal(struct {
			Room, Viewer int64
			ViewerName   string
			Record       database.Message
		}{room.ID, viewer, viewerName, commit.Message})
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(dir, "fixture.json"), raw, 0600); err != nil {
			t.Fatal(err)
		}
	}
}
