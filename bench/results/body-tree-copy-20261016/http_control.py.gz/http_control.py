"""Bounded complete JSON controls for long/short ordered, unordered, ordinary text."""
import hashlib
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import socket
import sqlite3
import statistics
import subprocess
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SEED = ROOT / '.cache/parity-seeds/default'
CLIENT = ROOT / '.cache/frame-writev-headtohead-20261014/binaries/httprate-mac'
loader = importlib.machinery.SourceFileLoader('upgrade', str(ROOT / 'bin/check-upgrade'))
spec = importlib.util.spec_from_loader(loader.name, loader)
u = importlib.util.module_from_spec(spec)
loader.exec_module(u)
labels = json.loads((SEED / 'labels.json').read_text())
env = {k: v for k, v in os.environ.items() if not k.startswith(('CAMPFIRE_', 'THRUSTER_', 'GO_CPU_', 'GO_ALLOC_', 'PERF_TREE_')) and k != 'TLS_DOMAIN'}
for line in (ROOT / 'reference/parity/.env.reference').read_text().splitlines():
    if line and not line.startswith('#') and '=' in line:
        k, v = line.split('=', 1)
        env[k] = v
env.update(DISABLE_SSL='true', TARGET_BIND='127.0.0.1', GOMAXPROCS='4')

def port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]

def backup(source, destination):
    with sqlite3.connect(f'file:{source}?mode=ro', uri=True) as src, sqlite3.connect(destination) as dst:
        src.backup(dst)

def fetch(base, path, cookie):
    with urllib.request.urlopen(urllib.request.Request(base + path, headers={'Cookie': cookie, 'Accept-Encoding': 'identity'}), timeout=10) as response:
        body = response.read()
        assert response.status == 200 and response.headers['Content-Type'].startswith('application/json')
        return response.headers, body

cases = ['unordered', 'ordered', 'short', 'paragraph', 'dense']
fixtures = OUT / 'fixtures'
for case in cases:
    directory = fixtures / case
    directory.mkdir(parents=True)
    backup(SEED / 'db/production.sqlite3', directory / 'production.sqlite3')
with (OUT / 'fixture-build.log').open('w') as log:
    subprocess.run([str(OUT / 'baseline.test'), '-test.run', '^TestBuildTreeProbeFixtures$'], cwd=ROOT,
                   env=os.environ | {'PERF_TREE_OUT': str(fixtures), 'PERF_TREE_LABELS': str(SEED / 'labels.json'), 'PERF_TREE_SECRET': env['SECRET_KEY_BASE']},
                   stdout=log, stderr=subprocess.STDOUT, check=True)
orders = [['baseline', 'candidate'], ['candidate', 'baseline'], ['baseline', 'candidate']]
metadata = {'baseline': 'c0449f2, runtime same as published PRbd604ab', 'candidate': 'borrow read-only original before mandatory body normalization when no attachments',
            'platform': os.uname().sysname, 'machine': os.uname().machine, 'cases': cases, 'orders': orders,
            'binaries': {a: hashlib.sha256((OUT / (a + '-mac')).read_bytes()).hexdigest() for a in ['baseline', 'candidate']},
            'client_sha256': hashlib.sha256(CLIENT.read_bytes()).hexdigest(),
            'seed_sha256': hashlib.sha256((SEED / 'db/production.sqlite3').read_bytes()).hexdigest(),
            'method': 'Complete cookie-authenticated one-record JSON feed,250offeredGETs/s,8workers,identity,timerpacing,2warm+8timedseconds. Source defaults and GOMAXPROCS4 matched. wait4 joined process CPU includesstartup/login/preflight/warmup/finalchecks/shutdown, excludesclient/fixturecost. No task-owned agents/tests/builds/profilers duringtiming.',
            'limits': 'Local Mac work evidence only; nonexclusivehost,three short pairs; no native latency/capacity/ranking or general message-speed claim.'}
(OUT / 'http-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
results, canonical = [], {}
for case in cases:
    fixture = json.loads((fixtures / case / 'fixture.json').read_text())
    record = fixture['Record']
    path = f'/rooms/{fixture["Room"]}/list-perf/messages'
    n = 20 if case == 'short' else 1000
    expected = ('Ordinary message & text' if case == 'paragraph' else
                '\n\n'.join('Hi @' + fixture['ViewerName'] for _ in range(20)) if case == 'dense' else
                '\n'.join(f'{i}. Item {i}' if case != 'unordered' else f'• Item {i}' for i in range(1, n + 1)))
    for rep, arms in enumerate(orders, 1):
        for arm in arms:
            label = f'http-{case}-{arm}-{rep}'
            with tempfile.TemporaryDirectory(prefix=label + '-', dir=OUT) as temp:
                work = Path(temp)
                db = work / 'production.sqlite3'
                backup(fixtures / case / 'production.sqlite3', db)
                with sqlite3.connect(db) as conn:
                    populations = [conn.execute('SELECT count(*) FROM ' + table).fetchone()[0] for table in ['users', 'rooms', 'messages']]
                    fk = conn.execute('PRAGMA foreign_key_check').fetchall()
                    # Fixture creation uses canonical production writes. Check
                    # exact persisted search text independently of read output.
                    assert conn.execute('SELECT body FROM message_search_index WHERE rowid=?', (record['ID'],)).fetchone() == (expected,)
                front, target = port(), port()
                while target == front:
                    target = port()
                base = f'http://127.0.0.1:{front}'
                runenv = env | {'HTTP_PORT': str(front), 'TARGET_PORT': str(target), 'CAMPFIRE_DATABASE_PATH': str(db), 'CAMPFIRE_STORAGE_PATH': str(work / 'storage')}
                with (OUT / (label + '.log')).open('w') as log:
                    proc = subprocess.Popen([str(OUT / (arm + '-mac')), 'server'], cwd=ROOT, env=runenv, stdout=log, stderr=subprocess.STDOUT)
                    try:
                        for _ in range(300):
                            if proc.poll() is not None:
                                raise RuntimeError('early server exit')
                            try:
                                with urllib.request.urlopen(base + '/up', timeout=1) as response:
                                    assert response.read() == u.helper.EXPECTED
                                break
                            except OSError:
                                time.sleep(.025)
                        else:
                            raise RuntimeError('startup timeout')
                        cookie = u.login(base, labels)
                        checks = []
                        for query in ['', f'?after={record["ID"]}', f'?before={record["ID"]}']:
                            headers, body = fetch(base, path + query, cookie)
                            values = json.loads(body)
                            assert headers['X-Total-Count'] == '1' and not headers.get('Link')
                            if query == '':
                                assert len(values) == 1 and values[0]['id'] == record['ID']
                                assert values[0]['body']['plain_text'] == expected
                                if case not in ['paragraph', 'dense']:
                                    assert values[0]['body']['html'].count('<li>') == n
                                if case == 'dense':
                                    assert values[0]['body']['html'].count('class="mention"') == 20
                            else:
                                assert values == []
                            identity = {'sha256': hashlib.sha256(body.replace(base.encode(), b'http://benchmark.invalid')).hexdigest(), 'count': headers['X-Total-Count'], 'link': headers.get('Link', '')}
                            key = (case, query)
                            if key in canonical:
                                assert canonical[key] == identity
                            else:
                                canonical[key] = identity
                            checks.append({'query': query, **identity})
                        for duration in [2, 8]:
                            raw = subprocess.check_output([str(CLIENT), '--base', base, '--cookie', cookie, '--path', path, '--gzip', '0', '--rate', '250', '--conc', '8', '--queue', '8192', '--pacing', 'timer', '--duration', str(duration)], text=True)
                            sample = json.loads(raw)
                            (OUT / f'{label}-{duration}s.json').write_text(raw)
                            assert sample['ok'] == 250 * duration and sample['errors'] == 0 and sample['unscheduled'] == 0
                            assert sample['statuses'] == {'200': 250 * duration}
                        _, body = fetch(base, path, cookie)
                        assert hashlib.sha256(body.replace(base.encode(), b'http://benchmark.invalid')).hexdigest() == canonical[(case, '')]['sha256']
                    finally:
                        if proc.returncode is None:
                            proc.terminate()
                            pid, status, usage = os.wait4(proc.pid, 0)
                            proc.returncode = os.waitstatus_to_exitcode(status)
                        else:
                            raise RuntimeError('server exited before accounting')
                    assert pid == proc.pid and proc.returncode == 0
                with sqlite3.connect(db) as conn:
                    assert conn.execute('PRAGMA integrity_check').fetchone() == ('ok',)
                    assert conn.execute('PRAGMA foreign_key_check').fetchall() == fk
                    assert [conn.execute('SELECT count(*) FROM ' + table).fetchone()[0] for table in ['users', 'rooms', 'messages']] == populations
                row = {'case': case, 'rep': rep, 'arm': arm, 'cpu': usage.ru_utime + usage.ru_stime, 'user_cpu': usage.ru_utime, 'system_cpu': usage.ru_stime, 'complete_gets': 2500, 'preflight': checks, 'exact_fts_text': True, 'integrity': 'ok', 'unchanged_populations_seed_fk': True, 'exit_code': proc.returncode}
                results.append(row)
                (OUT / 'http-results.json').write_text(json.dumps(results, indent=2) + '\n')
                print(label, 'joinedCPU', row['cpu'], flush=True)
summary = {}
for case in cases:
    medians = {a: statistics.median(r['cpu'] for r in results if r['case'] == case and r['arm'] == a) for a in ['baseline', 'candidate']}
    medians['change_percent'] = 100 * (medians['candidate'] / medians['baseline'] - 1)
    summary[case] = medians
    print(case, medians, flush=True)
(OUT / 'http-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
