"""Focused bot JSON parsing checks using the existing HTTP/state verifier."""
import importlib.machinery
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'bin'))
loader = importlib.machinery.SourceFileLoader('bot_json_contract', str(ROOT / 'bin/check-parity'))
spec = importlib.util.spec_from_loader(loader.name, loader)
p = importlib.util.module_from_spec(spec)
loader.exec_module(p)
original = p.WORKFLOWS['message_lifecycle']


def stored_body(app, message):
    return app.rows("SELECT coalesce(r.body,'') FROM messages m LEFT JOIN action_text_rich_texts r ON r.record_type='Message' AND r.name='body' AND r.record_id=m.id WHERE m.id=?", (message,))[0][0]


def bot_json(app):
    original(app)
    assert app.login('david')[0] == 302
    room = app.labels['rooms.watercooler']
    path = f'/rooms/{room}/api/messages'
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    baseline_count = app.rows('SELECT count(*) FROM messages')[0][0]
    for raw in [b'{"incomplete":', b'{} {}', b' \r\n']:
        status, _, _, _ = app.fetch('david', 'POST', path, raw, headers)
        assert status == 400, ('invalid JSON must not create message', raw, status)
        assert app.rows('SELECT count(*) FROM messages')[0][0] == baseline_count

    status, _, _, _ = app.fetch('david', 'POST', path + '?attachment=', b'', {'Content-Type': 'application/x-www-form-urlencoded'})
    assert status == 422, ('empty attachment must not bypass body presence check', status)
    raw = b'{"text":"literal JSON body"}'
    status, location, _, _ = app.fetch('david', 'POST', path, raw, headers)
    assert status == 201, ('valid JSON raw-body create', status)
    message = int(location.rsplit('/', 1)[-1])
    assert stored_body(app, message) == raw.decode()
    update = path + '/' + str(message)

    for raw, expected_status, expected_body in [
        (b'{"incomplete":', 400, '{"text":"literal JSON body"}'),
        (b' \n', 400, '{"text":"literal JSON body"}'),
        (b'{"attachment":"invalid"}', 500, '{"text":"literal JSON body"}'),
        (b'{"attachment":"","":"must not become body"}', 200, '{"text":"literal JSON body"}'),
        (b'{"attachment":null}', 200, '{"attachment":null}'),
    ]:
        status, _, _, body = app.fetch('david', 'PUT', update, raw, headers)
        assert status == expected_status, ('JSON update status', raw, status, expected_status)
        assert stored_body(app, message) == expected_body, ('JSON update mutated wrong body', raw)
        if status == 200:
            assert json.loads(body)['id'] == message
    # A present empty attachment selects attachment-only attributes at creation,
    # whereas null selects the raw body. This distinction comes from the reference.
    status, location, _, _ = app.fetch('david', 'POST', path, b'{"attachment":""}', headers)
    assert status == 201, ('empty attachment create', status)
    empty = int(location.rsplit('/', 1)[-1])
    assert stored_body(app, empty) == ''
    assert app.rows('PRAGMA integrity_check') == [('ok',)]
    print('PASS: bot JSON rejection, raw text and attachment/null body ownership', flush=True)


p.WORKFLOWS['message_lifecycle'] = bot_json
if __name__ == '__main__':
    raise SystemExit(p.main())
