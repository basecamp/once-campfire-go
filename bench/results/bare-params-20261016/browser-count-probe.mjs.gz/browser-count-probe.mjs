#!/usr/bin/env node
// Cross-implementation browser flows, adapted from once-campfire-go/bin/check-browser.mjs.
// Run against a disposable, freshly installed production server: node browser/smoke.mjs --base URL.
// This functional gate complements the screenshot inventory.
import { mkdtemp, rm } from "node:fs/promises"
import { chromium } from "playwright"

const baseIndex = process.argv.indexOf("--base")
const base = baseIndex < 0 ? null : process.argv[baseIndex + 1]
if (!base || !/^https?:\/\//.test(base))
  throw new Error("--base must specify a disposable fresh server")
const work = await mkdtemp("/tmp/campfire-browser-smoke-")
const errors = []
let browser
try {
  let ready = false
  for (let i = 0; i < 100; i++) {
    try {
      ready = (await fetch(`${base}/up`)).ok
    } catch {}
    if (ready) break
    await new Promise((resolve) => setTimeout(resolve, 50))
  }
  if (!ready) throw new Error(`Server did not become ready: ${base}`)
  browser = await chromium.launch({
    headless: true,
    env: { ...process.env, TMPDIR: work },
  })
  const context = await browser.newContext({
    permissions: ["clipboard-read", "clipboard-write"],
  })
  async function settled(page) {
    await page.waitForFunction(() => !document.querySelector('form[aria-busy="true"], html[aria-busy="true"], turbo-frame[aria-busy="true"]'))
  }
  async function navigate(page, url) {
    await settled(page)
    await page.goto(url)
  }
  function watch(page) {
    const failedRequests = []
    page.on("requestfailed", (request) => {
      failedRequests.push(`${request.method()} ${request.url()} ${request.failure()?.errorText}`)
    })
    if (process.env.DEBUG_BROWSER) {
      page.on("response", async (res) => {
        if (
          res.request().method() !== "GET" ||
          new URL(res.url()).pathname.startsWith("/rooms/") ||
          res.status() >= 400
        )
          console.error(
            res.status(),
            res.url(),
            (await res.text().catch(() => "")).slice(0, 500),
          )
      })
      page.on("websocket", (ws) =>
        ws.on("framereceived", ({ payload }) =>
          console.error("WS", String(payload).slice(0, 700)),
        ),
      )
    }
    page.on("pageerror", (error) => {
      errors.push(`${error.stack || String(error)} on ${page.url()}\n${failedRequests.slice(-5).join("\n")}`)
      if (process.env.DEBUG_BROWSER) console.error(error)
    })
    page.on("console", (msg) => {
      if (msg.type() === "error") {
        errors.push(msg.text())
        if (process.env.DEBUG_BROWSER) console.error(msg.text())
      }
    })
    return new Promise((resolve) =>
      page.on("websocket", (socket) =>
        socket.on("framereceived", ({ payload }) => {
          const frame = JSON.parse(String(payload))
          if (
            frame.type === "confirm_subscription" &&
            JSON.parse(frame.identifier).channel === "RoomMessagesChannel"
          )
            resolve()
        }),
      ),
    )
  }
  const first = await context.newPage()
  const firstSubscribed = watch(first)
  await navigate(first, `${base}/first_run`)
  await first.locator('[name="user[name]"]').fill("Browser User")
  await first
    .locator('[name="user[email_address]"]')
    .fill("browser@example.test")
  await first.locator('[name="user[password]"]').fill("browser test password")
  await Promise.all([
    first.waitForURL("**/rooms/*"),
    first
      .locator('form:has(input[name="user[name]"]) button[type="submit"]')
      .click(),
  ])
  const roomURL = first.url()
  const second = await context.newPage()
  const secondSubscribed = watch(second)
  await navigate(second, first.url())
  await Promise.race([
    Promise.all([firstSubscribed, secondSubscribed]),
    new Promise((_, reject) =>
      setTimeout(
        () => reject(new Error("subscription timeout")),
        10000,
      ).unref(),
    ),
  ])
  await first
    .getByRole("textbox", { name: "Write a message", exact: true })
    .fill("Hello from the first tab")
  await first.getByRole("button", { name: "Send Message", exact: true }).click()
  await second
    .locator(".messages > .message[data-message-id]")
    .filter({ hasText: "Hello from the first tab" })
    .waitFor()
  await second
    .getByRole("textbox", { name: "Write a message", exact: true })
    .fill("Reply from the second tab")
  await second
    .getByRole("button", { name: "Send Message", exact: true })
    .click()
  await first
    .locator(".messages > .message[data-message-id]")
    .filter({ hasText: "Reply from the second tab" })
    .waitFor()
  await first.waitForFunction(() => document.querySelectorAll('.messages > .message[data-message-id]').length === 2)
  if (process.env.DIAG_HOLD_RENDER === '1') {
    await first.evaluate(() => {
      const gate = new Promise(resolve => { window.__diagRelease = resolve })
      window.__diagHeld = 0
      window.addEventListener('turbo:before-stream-render', event => {
        if (!event.target.querySelector('template')?.content.textContent.includes('safe browser text')) return
        const render = event.detail.render
        event.detail.render = async function (...args) { await gate; return render.apply(this, args) }
        window.__diagHeld++
      })
    })
  }
  await first.locator("lexxy-editor#message_body").evaluate((el) => {
    el.value =
      '<img src=x onerror="window.injected=true"><b>safe browser text</b>'
  })
  await first.getByRole("button", { name: "Send Message", exact: true }).click()
  await second
    .locator(".messages > .message[data-message-id]")
    .filter({ hasText: "safe browser text" })
    .waitFor()
  async function countSnapshot(page, tab, phase) {
    const state = await page.evaluate(() => ({
      persisted: Array.from(document.querySelectorAll('.messages > .message[data-message-id]'), node => ({dom:node.id, id:node.getAttribute('data-message-id')})),
      pending: Array.from(document.querySelectorAll('.messages > .message[id^="message_"]:not([data-message-id])'), node => node.id),
      busy: !!document.querySelector('form[aria-busy="true"]'),
      injected: window.injected === true,
      held: window.__diagHeld || 0,
    }))
    console.log(JSON.stringify({tab, phase, controlled:process.env.DIAG_HOLD_RENDER === '1', ...state}))
    return state
  }
  const before = []
  for (const [tab, page] of [['sender', first], ['receiver', second]]) {
    const state = await countSnapshot(page, tab, 'assertion')
    before.push(state)
    if (state.injected) throw new Error('stored markup executed')
  }
  const originalPass = before.every(state => state.persisted.length === 3)
  if (process.env.DIAG_HOLD_RENDER === '1') {
    if (before[0].persisted.length !== 2 || before[0].pending.length !== 1 || before[1].persisted.length !== 3 || !before[0].held) {
      throw new Error('controlled schedule did not isolate the expected sender phase')
    }
    await first.evaluate(() => window.__diagRelease())
  }
  for (const [tab, page] of [['sender', first], ['receiver', second]]) {
    await page.waitForFunction(() => document.querySelectorAll('.messages > .message[data-message-id]').length >= 3)
    const state = await countSnapshot(page, tab, 'completed')
    if (state.persisted.length !== 3 || new Set(state.persisted.map(node=>node.id)).size !== 3 || state.pending.length !== 0) throw new Error('duplicate or missing message after sender completion')
    if (state.injected) throw new Error('stored markup executed')
  }
  if (errors.length) throw new Error(errors.join('\n'))
  console.log(JSON.stringify({result: 'diagnostic-complete', originalAssertionPassed:originalPass, controlled:process.env.DIAG_HOLD_RENDER === '1'}))
  if (!originalPass && process.env.DIAG_HOLD_RENDER !== '1') process.exitCode = 1
} finally {
  await browser?.close()
  await rm(work, {recursive:true, force:true})
}
