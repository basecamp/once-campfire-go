"""Real bot-key bare/null parameter checks, extending the maintained HTTP workflow."""
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('json_contract', ROOT / '.cache/bot-json-params-20261016/http_contract.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
p = module.p
original = p.WORKFLOWS['message_lifecycle']


def bare_params(app):
    original(app)
    status, _, _ = app.request('david', 'POST', '/account/bots', {'user[name]': 'Bare parameter bot', 'user[webhook_url]': ''})
    assert status == 302, ('create bot', status)
    bot, token = app.rows("SELECT id,bot_token FROM users WHERE name='Bare parameter bot'")[0]
    key = f'{bot}-{token}'
    room = app.rows("SELECT r.id FROM rooms r JOIN memberships m ON m.room_id=r.id WHERE m.user_id=? AND r.type='Rooms::Open' ORDER BY r.id LIMIT 1", (bot,))[0][0]
    path = f'/rooms/{room}/{key}/messages'

    def fetch(method, query, body, media):
        try:
            return app.fetch('unauthenticated-bot', method, path + query, body.encode(), {'Content-Type': media})
        finally:
            app.trace[-1]['path'] = app.trace[-1]['path'].replace(key, '[generated-bot-key]')

    for name, query, media, raw, expected in [
        ('bare query', '?attachment', 'text/plain', 'attachment bareneedle', 'attachment bareneedle'),
        ('empty query', '?attachment=', 'text/plain', 'attachment bareneedle', ''),
        ('bare form', '', 'application/x-www-form-urlencoded', 'attachment', 'attachment'),
        ('empty form', '', 'application/x-www-form-urlencoded', 'attachment=', ''),
        ('last query null', '?attachment=invalid&attachment', 'text/plain', 'attachment bareneedle', 'attachment bareneedle'),
        ('last query empty', '?attachment&attachment=', 'text/plain', 'attachment bareneedle', ''),
        ('query null beats form', '?attachment', 'application/x-www-form-urlencoded', 'attachment=invalid', 'attachment=invalid'),
        ('query empty beats form null', '?attachment=', 'application/x-www-form-urlencoded', 'attachment', ''),
    ]:
        status, location, _, _ = fetch('POST', query, raw, media)
        assert status == 201, (name, 'status', status)
        message = int(location.rsplit('/', 1)[-1])
        creator = app.rows('SELECT creator_id FROM messages WHERE id=?', (message,))[0][0]
        assert creator == bot, (name, 'not bot-key authenticated')
        assert module.stored_body(app, message) == expected, (name, 'raw body lost')
        found = app.rows("SELECT rowid FROM message_search_index WHERE message_search_index MATCH 'attachment' AND rowid=?", (message,))
        assert bool(found) == ('attachment' in expected), (name, 'FTS does not match body')
    assert app.rows('PRAGMA integrity_check') == [('ok',)]
    print('PASS: actual bot-key/null-vs-empty/source precedence and committed body/FTS', flush=True)


p.WORKFLOWS['message_lifecycle'] = bare_params
if __name__ == '__main__':
    raise SystemExit(p.main())
