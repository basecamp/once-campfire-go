"""Focused push-registration scope checks around the maintained account workflow."""
import importlib.machinery
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'bin'))
loader = importlib.machinery.SourceFileLoader('parity', str(ROOT / 'bin/check-parity'))
spec = importlib.util.spec_from_loader(loader.name, loader)
p = importlib.util.module_from_spec(spec)
loader.exec_module(p)
original = p.WORKFLOWS['account_settings']


def push_params(app):
    original(app)
    assert app.login('david')[0] == 302
    user = app.rows('SELECT id FROM users WHERE email_address=?', (app.labels['emails.david'],))[0][0]
    before = app.rows('SELECT id,user_id,endpoint,p256dh_key,auth_key FROM push_subscriptions ORDER BY id')
    valid = '{"endpoint":"https://fcm.googleapis.com/scope-test","p256dh_key":"body-key","auth_key":"body-auth"}'
    path = '/users/me/push_subscriptions'
    for name, query, media, body, expected in [
        ('empty nested root', '', 'application/json', '{"endpoint":"https://fcm.googleapis.com/scope-test","push_subscription":{}}', 400),
        ('outer fields do not fill nested root', '', 'application/json', '{"endpoint":"https://fcm.googleapis.com/scope-test","push_subscription":{"auth_key":"nested-auth"}}', 422),
        ('query clears JSON root', '?push_subscription=', 'application/json', valid, 400),
        ('query replaces nested JSON root', '?push_subscription[auth_key]=query-auth', 'application/json', '{"push_subscription":'+valid+'}', 422),
        ('query prevents JSON wrapping', '?push_subscription[auth_key]=query-auth', 'application/json', valid, 422),
        ('query replaces form root', '?push_subscription[auth_key]=query-auth', 'application/x-www-form-urlencoded', 'push_subscription%5Bendpoint%5D=https%3A%2F%2Ffcm.googleapis.com%2Fscope-test&push_subscription%5Bp256dh_key%5D=body-key', 422),
    ]:
        status, _, _, _ = app.fetch('david', 'POST', path+query, body.encode(), {'Content-Type': media})
        after = app.rows('SELECT id,user_id,endpoint,p256dh_key,auth_key FROM push_subscriptions ORDER BY id')
        assert (status, after) == (expected, before), (name, 'status', status, 'expected', expected, 'subscriptions changed', after != before)
    boundary = 'campfire-push-scope-boundary'
    form = ('--'+boundary+'\r\nContent-Disposition: form-data; name="push_subscription[endpoint]"\r\n\r\nhttps://fcm.googleapis.com/scope-test\r\n--'+boundary+'--\r\n').encode()
    status, _, _, _ = app.fetch('david', 'POST', path+'?push_subscription[auth_key]=query-auth', form, {'Content-Type': 'multipart/form-data; boundary='+boundary})
    assert status == 422 and app.rows('SELECT id,user_id,endpoint,p256dh_key,auth_key FROM push_subscriptions ORDER BY id') == before
    other = app.rows('SELECT id FROM users WHERE email_address=?', (app.labels['emails.kevin'],))[0][0]
    status, _, _, _ = app.fetch('david', 'POST', f'/users/{other}/push_subscriptions?endpoint=https://localhost/not-selected', b'{"endpoint":"https://fcm.googleapis.com/scalar-test","p256dh_key":7,"auth_key":true}', {'Content-Type':'Application/JSON; charset=utf-8'})
    assert status == 200, ('typed registration', status)
    records = app.rows('SELECT id,user_id,endpoint,p256dh_key,auth_key FROM push_subscriptions WHERE endpoint=?', ('https://fcm.googleapis.com/scalar-test',))
    assert len(records) == 1 and records[0][1:] == (user, 'https://fcm.googleapis.com/scalar-test', '7', 'true'), 'selected credentials/current user differ'
    subscription = records[0][0]
    assert app.login('kevin')[0] == 302
    assert app.request('kevin', 'DELETE', f'{path}/{subscription}')[0] == 302
    assert app.rows('SELECT id,user_id,endpoint,p256dh_key,auth_key FROM push_subscriptions WHERE id=?', (subscription,)) == records, 'other user deleted subscription'
    assert app.request('david', 'DELETE', f'{path}/{subscription}')[0] == 302
    assert app.rows('SELECT id,user_id,endpoint,p256dh_key,auth_key FROM push_subscriptions ORDER BY id') == before
    assert app.rows('PRAGMA integrity_check') == [('ok',)]
    print('PASS: push root selection/rejection, selected credentials and current-user ownership', flush=True)


original_metadata = p.WORKFLOWS['upload_metadata']


def ordered_metadata(app):
    original_metadata(app)
    assert app.login('david')[0] == 302
    boundary = 'campfire-ordered-metadata-boundary'
    pairs = [('blob[filename]', 'ordered.txt'), ('blob[byte_size]', '0'), ('blob[checksum]', '1B2M2Y8AsgTpgAmY7PhCfg==')]
    pairs += [('blob[metadata][items][]['+key+']', value) for key, value in [('a','1'), ('b','2'), ('a','3'), ('b','4')]]
    payload = ''.join('--'+boundary+'\r\nContent-Disposition: form-data; name="'+key+'"\r\n\r\n'+value+'\r\n' for key, value in pairs) + '--'+boundary+'--\r\n'
    status, _, _, data = app.fetch('david', 'POST', '/rails/active_storage/direct_uploads', payload.encode(), {'Content-Type':'multipart/form-data; boundary='+boundary})
    assert status == 200, ('ordered metadata', status)
    record = json.loads(data)
    expected = {'items':[{'a':'1','b':'2'},{'a':'3','b':'4'}]}
    assert record['metadata'] == expected, 'response multipart grouping differs'
    stored = app.rows('SELECT metadata FROM active_storage_blobs WHERE id=?', (record['id'],))[0][0]
    assert json.loads(stored) == expected, 'persisted multipart grouping differs'
    print('PASS: ordered multipart metadata response and committed grouping', flush=True)


p.WORKFLOWS['account_settings'] = push_params
p.WORKFLOWS['upload_metadata'] = ordered_metadata
if __name__ == '__main__':
    raise SystemExit(p.main())
