package application

// Temporary diagnostic input, removed before delivery.
import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/basecamp/once-campfire-go/internal/database"
	"github.com/basecamp/once-campfire-go/internal/presentation"
	"github.com/basecamp/once-campfire-go/internal/rails"
)

func listProbeBody(kind string) string {
	if kind == "paragraph" {
		return "<p>Ordinary message &amp; text</p>"
	}
	tag, n := "ol", 1000
	if kind == "short" {
		n = 20
	}
	if kind == "unordered" {
		tag = "ul"
	}
	var b strings.Builder
	b.WriteString("<" + tag + ">")
	for i := 1; i <= n; i++ {
		fmt.Fprintf(&b, "<li>Item %d</li>", i)
	}
	b.WriteString("</" + tag + ">")
	return b.String()
}

func TestListSearchWriteProbe(t *testing.T) {
	db, err := database.Open(filepath.Join(t.TempDir(), "writes.sqlite3"), 4)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	ctx := context.Background()
	user, err := db.Setup(ctx, "Owner", "owner@test", "digest")
	if err != nil {
		t.Fatal(err)
	}
	rooms, err := db.Rooms(ctx, user.ID)
	if err != nil {
		t.Fatal(err)
	}
	body := listProbeBody("ordered")
	commit, err := db.CreateMessage(ctx, user.ID, rooms[0].ID, database.MessageInput{Body: &body})
	if err != nil {
		t.Fatal(err)
	}
	for _, count := range []int{1000, 20} {
		if count == 20 {
			body = listProbeBody("short")
			if _, err = db.UpdateMessage(ctx, user.ID, commit.ID, database.MessageInput{Body: &body}); err != nil {
				t.Fatal(err)
			}
		}
		var lines []string
		for i := 1; i <= count; i++ {
			lines = append(lines, fmt.Sprintf("%d. Item %d", i, i))
		}
		var stored string
		if err = db.Read.QueryRowContext(ctx, "SELECT body FROM message_search_index WHERE rowid=?", commit.ID).Scan(&stored); err != nil {
			t.Fatal(err)
		}
		if stored != strings.Join(lines, "\n") {
			t.Fatalf("persisted list text changed for %d items", count)
		}
	}
}

func BenchmarkListTextProbe(b *testing.B) {
	for _, kind := range []string{"ordered", "short", "unordered", "paragraph"} {
		b.Run(kind, func(b *testing.B) {
			ctx := context.Background()
			db, err := database.Open(filepath.Join(b.TempDir(), "probe.sqlite3"), 4)
			if err != nil {
				b.Fatal(err)
			}
			defer db.Close()
			user, err := db.Setup(ctx, "Owner", "owner@test", "digest")
			if err != nil {
				b.Fatal(err)
			}
			rooms, err := db.Rooms(ctx, user.ID)
			if err != nil {
				b.Fatal(err)
			}
			body := listProbeBody(kind)
			commit, err := db.CreateMessage(ctx, user.ID, rooms[0].ID, database.MessageInput{Body: &body})
			if err != nil {
				b.Fatal(err)
			}
			secrets, err := rails.NewSecrets("list-probe-only")
			if err != nil {
				b.Fatal(err)
			}
			renderer, err := presentation.NewRenderer(secrets)
			if err != nil {
				b.Fatal(err)
			}
			q := MessageQueries{DB: db, Presentation: renderer}
			facts := presentation.Facts{Host: "benchmark.invalid", Origin: "http://benchmark.invalid", Now: db.Now()}
			b.ReportAllocs()
			b.ResetTimer()
			for b.Loop() {
				result, err := q.APIRecord(ctx, facts, commit.Message)
				if err != nil {
					b.Fatal(err)
				}
				switch kind {
				case "ordered":
					if !strings.HasSuffix(result.Body.Plain, "1000. Item 1000") {
						b.Fatal("numbering changed")
					}
				case "short":
					if !strings.HasSuffix(result.Body.Plain, "20. Item 20") {
						b.Fatal("numbering changed")
					}
				case "unordered":
					if !strings.HasSuffix(result.Body.Plain, "• Item 1000") {
						b.Fatal("bullet changed")
					}
				}
			}
		})
	}
}

func TestBuildListProbeFixtures(t *testing.T) {
	out := os.Getenv("PERF_LIST_OUT")
	if out == "" {
		return
	}
	raw, err := os.ReadFile(os.Getenv("PERF_LIST_LABELS"))
	if err != nil {
		t.Fatal(err)
	}
	var labels map[string]json.RawMessage
	if err = json.Unmarshal(raw, &labels); err != nil {
		t.Fatal(err)
	}
	var email string
	if err = json.Unmarshal(labels["emails.david"], &email); err != nil {
		t.Fatal(err)
	}
	for _, kind := range []string{"ordered", "short", "unordered", "paragraph"} {
		dir := filepath.Join(out, kind)
		db, err := database.Open(filepath.Join(dir, "production.sqlite3"), 4)
		if err != nil {
			t.Fatal(err)
		}
		var viewer int64
		if err = db.Read.QueryRow("SELECT id FROM users WHERE email_address=?", email).Scan(&viewer); err != nil {
			t.Fatal(err)
		}
		db.Now = func() time.Time { return time.Date(2026, 10, 16, 12, 0, 0, 0, time.UTC) }
		name := sql.NullString{String: "List performance", Valid: true}
		room, err := db.CreateRoom(context.Background(), viewer, "Rooms::Open", &name, nil)
		if err != nil {
			t.Fatal(err)
		}
		body := listProbeBody(kind)
		commit, err := db.CreateMessage(context.Background(), viewer, room.ID, database.MessageInput{Body: &body})
		if err != nil {
			t.Fatal(err)
		}
		if err = db.Close(); err != nil {
			t.Fatal(err)
		}
		raw, err = json.Marshal(struct {
			Room, Viewer int64
			Record       database.Message
		}{room.ID, viewer, commit.Message})
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(dir, "fixture.json"), raw, 0600); err != nil {
			t.Fatal(err)
		}
	}
}
