"""Extend the maintained pagination workflow with the demonstrated scalar regressions."""
import importlib.machinery
import importlib.util
import json
import sys
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'bin'))
loader = importlib.machinery.SourceFileLoader('pagination_contract', str(ROOT / 'bin/check-parity'))
spec = importlib.util.spec_from_loader(loader.name, loader)
p = importlib.util.module_from_spec(spec)
loader.exec_module(p)
original = p.WORKFLOWS['pagination']


def pagination(app):
    original(app)
    room = app.labels['rooms.watercooler']
    anchor = app.labels['messages.busy_060']
    other = app.rows('SELECT id FROM messages WHERE room_id=? ORDER BY created_at LIMIT 1', (room,))[0][0]
    total = app.rows('SELECT count(*) FROM messages WHERE room_id=?', (room,))[0][0]

    def page(direction, cursor):
        stamp = app.rows('SELECT created_at FROM messages WHERE id=?', (cursor,))[0][0]
        operator, order = ('<', 'DESC') if direction == 'before' else ('>', 'ASC')
        ids = [r[0] for r in app.rows(f'SELECT id FROM messages WHERE room_id=? AND created_at{operator}? ORDER BY created_at {order} LIMIT 40', (room, stamp))]
        return list(reversed(ids)) if direction == 'before' else ids

    cases = [
        (f'?before={anchor}', page('before', anchor), False, 200),
        (f'?after={anchor}', page('after', anchor), True, 200),
        (f'?before={other}&before={anchor}', page('before', anchor), False, 200),
        (f'?after={other}&after={anchor}', page('after', anchor), True, 200),
        (f'?before={anchor}&after={other}', page('before', anchor), True, 200),
        (f'?before={anchor}&after={other}&after=', page('before', anchor), False, 200),
        (f'?before=+0d{anchor}trailing&after=+', page('before', anchor), False, 200),
        ('?before=0', [], False, 404),
        (f'?before=invalid&after={anchor}', [], True, 404),
        ('?after=invalid', [], True, 404),
    ]
    for query, expected, link_after, expected_status in cases:
        for api in (False, True):
            endpoint = f'/rooms/{room}/' + ('api/messages' if api else 'messages')
            status, _, headers, body = app.fetch('david', 'GET', endpoint + query)
            assert status == expected_status, (endpoint + query, status, expected_status)
            if status != 200:
                continue
            ids = [m['id'] for m in json.loads(body)] if api else p.message_ids(body.decode())
            assert ids == expected, (endpoint + query, ids, expected)
            if not api:
                continue
            assert headers['X-Total-Count'] == str(total)
            link = ''
            if ids:
                boundary = ids[-1] if link_after else ids[0]
                stamp = app.rows('SELECT created_at FROM messages WHERE id=?', (boundary,))[0][0]
                op, key = ('>', 'after') if link_after else ('<', 'before')
                more = app.rows(f'SELECT EXISTS(SELECT 1 FROM messages WHERE room_id=? AND created_at{op}?)', (room, stamp))[0][0]
                if more:
                    link = f'<{endpoint}?{key}={boundary}>; rel="next"'
            actual = headers.get('Link', '').replace(app.base, '')
            assert actual == link, (endpoint + query, actual, link)
    print('PASS: scalar cursor statuses/IDs/counts/Link precedence against stored timestamps', flush=True)


p.WORKFLOWS['pagination'] = pagination
if __name__ == '__main__':
    raise SystemExit(p.main())
