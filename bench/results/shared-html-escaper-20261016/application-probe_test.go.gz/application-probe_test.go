package application

// Temporary diagnostic input; remove before delivery.
import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/basecamp/once-campfire-go/internal/database"
	"github.com/basecamp/once-campfire-go/internal/presentation"
	"github.com/basecamp/once-campfire-go/internal/rails"
)

type escapeFixture struct {
	Viewer, Room int64
	Records      []database.Message
}

func fillEscapeProbe(t testing.TB, db *database.DB, viewer, room int64, kind string, blob int64) escapeFixture {
	t.Helper()
	ctx := context.Background()
	fixture := escapeFixture{Viewer: viewer, Room: room}
	base := time.Date(2026, 10, 16, 12, 0, 0, 0, time.UTC)
	for i := 0; i < 40; i++ {
		db.Now = func() time.Time { return base.Add(time.Duration(i) * time.Second) }
		body := fmt.Sprintf("<p>Render message %02d &amp; body</p>", i)
		input := database.MessageInput{Body: &body}
		if kind != "plain" {
			input.Attachment = &blob
		}
		commit, err := db.CreateMessage(ctx, viewer, room, input)
		if err != nil {
			t.Fatal(err)
		}
		fixture.Records = append(fixture.Records, commit.Message)
	}
	return fixture
}

func BenchmarkRenderEscapeProbe(b *testing.B) {
	for _, kind := range []string{"file", "image", "plain", "warm"} {
		b.Run(kind, func(b *testing.B) {
			db, err := database.Open(filepath.Join(b.TempDir(), "probe.sqlite3"), 4)
			if err != nil {
				b.Fatal(err)
			}
			defer db.Close()
			ctx := context.Background()
			owner, err := db.Setup(ctx, "Owner", "owner@test", "digest")
			if err != nil {
				b.Fatal(err)
			}
			rooms, err := db.Rooms(ctx, owner.ID)
			if err != nil {
				b.Fatal(err)
			}
			typ := "text/plain"
			if kind == "image" {
				typ = "image/jpeg"
			}
			blob, err := db.CreateBlob(ctx, database.Blob{Filename: `report <&> "' snow 雪.txt`, ContentType: &typ, Metadata: json.RawMessage(`{"width":800,"height":600,"analyzed":true}`), ByteSize: 32})
			if err != nil {
				b.Fatal(err)
			}
			fillEscapeProbe(b, db, owner.ID, rooms[0].ID, kind, blob.ID)
			secrets, err := rails.NewSecrets("render-probe-only")
			if err != nil {
				b.Fatal(err)
			}
			renderer, err := presentation.NewRenderer(secrets)
			if err != nil {
				b.Fatal(err)
			}
			q := MessageQueries{DB: db, Presentation: renderer, Fragments: presentation.NewFragments(renderer, 32<<20)}
			scope := presentation.MessageScope{Facts: presentation.Facts{Host: "benchmark.invalid", Origin: "http://benchmark.invalid", Now: db.Now()}}
			if kind == "warm" {
				scope = q.Observe(ctx, scope.Facts)
				if _, _, err = q.Page(ctx, scope, owner.ID, rooms[0].ID, 0, "before", false); err != nil {
					b.Fatal(err)
				}
			}
			b.ReportAllocs()
			b.ResetTimer()
			for b.Loop() {
				part, count, err := q.Page(ctx, scope, owner.ID, rooms[0].ID, 0, "before", false)
				if err != nil || count != 40 || part.Len() == 0 {
					b.Fatalf("bad message page %d %v", count, err)
				}
				if _, err = part.WriteTo(io.Discard); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}

func TestBuildEscapeProbeFixtures(t *testing.T) {
	out := os.Getenv("PERF_ESCAPE_OUT")
	if out == "" {
		return
	}
	raw, err := os.ReadFile(os.Getenv("PERF_ESCAPE_LABELS"))
	if err != nil {
		t.Fatal(err)
	}
	var labels map[string]json.RawMessage
	if err = json.Unmarshal(raw, &labels); err != nil {
		t.Fatal(err)
	}
	var email string
	var room int64
	if err = json.Unmarshal(labels["emails.david"], &email); err != nil {
		t.Fatal(err)
	}
	if err = json.Unmarshal(labels["rooms.watercooler"], &room); err != nil {
		t.Fatal(err)
	}
	for _, kind := range []string{"file", "image", "plain"} {
		dir := filepath.Join(out, kind)
		db, err := database.Open(filepath.Join(dir, "production.sqlite3"), 4)
		if err != nil {
			t.Fatal(err)
		}
		var viewer, blob int64
		if err = db.Read.QueryRow("SELECT id FROM users WHERE email_address=?", email).Scan(&viewer); err != nil {
			t.Fatal(err)
		}
		if kind != "plain" {
			typ := "text/plain"
			if kind == "image" {
				typ = "image/jpeg"
			}
			if err = db.Read.QueryRow("SELECT id FROM active_storage_blobs WHERE content_type=? ORDER BY id LIMIT 1", typ).Scan(&blob); err != nil {
				t.Fatal(err)
			}
			if kind == "file" {
				if _, err = db.Write.Exec("UPDATE active_storage_blobs SET filename=? WHERE id=?", `report <&> "' snow 雪.txt`, blob); err != nil {
					t.Fatal(err)
				}
			}
		}
		fixture := fillEscapeProbe(t, db, viewer, room, kind, blob)
		if err = db.Close(); err != nil {
			t.Fatal(err)
		}
		raw, err = json.Marshal(fixture)
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(dir, "fixture.json"), raw, 0600); err != nil {
			t.Fatal(err)
		}
	}
}
