"""Complete identity HTML controls: cold file/image/plain pages and warm file hits."""
import hashlib
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import socket
import sqlite3
import statistics
import subprocess
import tempfile
import time
import urllib.request
import http.client

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SEED = ROOT / '.cache/parity-seeds/default'
loader = importlib.machinery.SourceFileLoader('upgrade', str(ROOT / 'bin/check-upgrade'))
spec = importlib.util.spec_from_loader(loader.name, loader)
u = importlib.util.module_from_spec(spec)
loader.exec_module(u)
labels = json.loads((SEED / 'labels.json').read_text())
env = {k: v for k, v in os.environ.items() if not k.startswith(('CAMPFIRE_', 'THRUSTER_', 'GO_CPU_', 'GO_ALLOC_', 'PERF_ESCAPE_')) and k != 'TLS_DOMAIN'}
for line in (ROOT / 'reference/parity/.env.reference').read_text().splitlines():
    if line and not line.startswith('#') and '=' in line:
        k, v = line.split('=', 1)
        env[k] = v
env.update(DISABLE_SSL='true', TARGET_BIND='127.0.0.1', GOMAXPROCS='4')

def backup(source, target):
    with sqlite3.connect(f'file:{source}?mode=ro', uri=True) as src, sqlite3.connect(target) as dst:
        src.backup(dst)

def port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]

fixtures = OUT / 'fixtures'
for case in ['file', 'image', 'plain']:
    directory = fixtures / case
    directory.mkdir(parents=True)
    backup(SEED / 'db/production.sqlite3', directory / 'production.sqlite3')
with (OUT / 'fixture-build.log').open('w') as log:
    subprocess.run([str(OUT / 'baseline.test'), '-test.run', '^TestBuildEscapeProbeFixtures$'], cwd=ROOT,
                   env=os.environ | {'PERF_ESCAPE_OUT': str(fixtures), 'PERF_ESCAPE_LABELS': str(SEED / 'labels.json')},
                   stdout=log, stderr=subprocess.STDOUT, check=True)
orders = [['baseline', 'candidate'], ['candidate', 'baseline'], ['baseline', 'candidate']]
metadata = {'baseline': '5af6df6, same runtime as published PR4dfa3fd', 'candidate': 'one shared fixed strings.Replacer for HTML escaping',
            'platform': os.uname().sysname, 'machine': os.uname().machine,
            'binaries': {arm: hashlib.sha256((OUT / (arm + '-mac')).read_bytes()).hexdigest() for arm in ['baseline', 'candidate']},
            'seed_sha256': hashlib.sha256((SEED / 'db/production.sqlite3').read_bytes()).hexdigest(),
            'orders': orders, 'cases': ['file', 'image', 'plain', 'warm'],
            'method': 'Each process: exact preflight+500warm+1500measured complete identity HTML GETs; normalizedSHA checked on every body. Cold cases commit independent ignored accountsettings nonce before each GET; warm case does not. Unchanged production caches/queues/GC, GOMAXPROCS4. No task-owned agents/checks/builds/profilers during timing. wait4 joined process CPU includes startup/login/shutdown; client/fixture/foreign-writer CPU excluded.',
            'limits': 'Local Mac CPU/work only, non-exclusive host, three short pairs; not native Fedora capacity/latency or image/video processing/output validation.'}
(OUT / 'http-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
results, canonical = [], {}
for case in metadata['cases']:
    fixture_case = 'file' if case == 'warm' else case
    fixture = json.loads((fixtures / fixture_case / 'fixture.json').read_text())
    expected_ids = [record['ID'] for record in fixture['Records']]
    for rep, arms in enumerate(orders, 1):
        for arm in arms:
            label = f'http-{case}-{arm}-{rep}'
            with tempfile.TemporaryDirectory(prefix=label + '-', dir=OUT) as temp:
                work = Path(temp)
                db = work / 'production.sqlite3'
                backup(fixtures / fixture_case / 'production.sqlite3', db)
                shutil.copytree(SEED / 'storage', work / 'storage')
                with sqlite3.connect(db) as conn:
                    counts = [conn.execute('SELECT count(*) FROM ' + table).fetchone()[0] for table in ['users', 'messages', 'active_storage_blobs', 'active_storage_attachments']]
                    fk = conn.execute('PRAGMA foreign_key_check').fetchall()
                    settings = json.loads(conn.execute('SELECT settings FROM accounts LIMIT 1').fetchone()[0] or '{}')
                front, target = port(), port()
                while target == front:
                    target = port()
                base = f'http://127.0.0.1:{front}'
                runenv = env | {'HTTP_PORT': str(front), 'TARGET_PORT': str(target),
                                'CAMPFIRE_DATABASE_PATH': str(db), 'CAMPFIRE_STORAGE_PATH': str(work / 'storage')}
                with (OUT / (label + '.log')).open('w') as log:
                    proc = subprocess.Popen([str(OUT / (arm + '-mac')), 'server'], cwd=ROOT, env=runenv, stdout=log, stderr=subprocess.STDOUT)
                    try:
                        for _ in range(300):
                            if proc.poll() is not None:
                                raise RuntimeError(label + ' exited before readiness')
                            try:
                                with urllib.request.urlopen(base + '/up', timeout=1) as response:
                                    assert response.read() == u.helper.EXPECTED
                                break
                            except OSError:
                                time.sleep(.025)
                        else:
                            raise RuntimeError('startup timeout')
                        cookie = u.login(base, labels)
                        client = http.client.HTTPConnection('127.0.0.1', front, timeout=15)
                        foreign = sqlite3.connect(db, isolation_level=None)
                        hashes = set()
                        for sequence in range(2001):
                            if case != 'warm':
                                foreign.execute("UPDATE accounts SET settings=json_set(coalesce(settings,'{}'),'$.benchmark_epoch',?)", (sequence,))
                            client.request('GET', f'/rooms/{fixture["Room"]}/messages', headers={'Cookie': cookie, 'Accept-Encoding': 'identity'})
                            response = client.getresponse()
                            body = response.read()
                            assert response.status == 200 and response.headers['Content-Type'].startswith('text/html')
                            normalized = body.replace(base.encode(), b'http://benchmark.invalid')
                            digest = hashlib.sha256(normalized).hexdigest()
                            hashes.add(digest)
                            if sequence == 0:
                                ids = [int(value) for value in re.findall(rb'data-message-id="(\d+)"', body)]
                                assert ids == expected_ids, (case, ids, expected_ids)
                                if fixture_case == 'file':
                                    assert 'report -&amp;- -&#39; snow 雪.txt'.encode() in body
                                if fixture_case == 'image':
                                    assert b'data-lightbox-url-value=' in body
                            key = fixture_case
                            if key not in canonical:
                                canonical[key] = digest
                            assert digest == canonical[key], (label, sequence, 'complete HTML changed')
                        client.close()
                        foreign.close()
                    finally:
                        if proc.returncode is None:
                            proc.terminate()
                            pid, status, usage = os.wait4(proc.pid, 0)
                            proc.returncode = os.waitstatus_to_exitcode(status)
                        else:
                            raise RuntimeError('server exited before joined accounting')
                    assert pid == proc.pid and proc.returncode == 0, (label, proc.returncode)
                with sqlite3.connect(db) as conn:
                    assert conn.execute('PRAGMA integrity_check').fetchone() == ('ok',)
                    assert conn.execute('PRAGMA foreign_key_check').fetchall() == fk
                    assert [conn.execute('SELECT count(*) FROM ' + table).fetchone()[0] for table in ['users', 'messages', 'active_storage_blobs', 'active_storage_attachments']] == counts
                    final = json.loads(conn.execute('SELECT settings FROM accounts LIMIT 1').fetchone()[0] or '{}')
                    if case != 'warm':
                        assert final.pop('benchmark_epoch') == 2000
                    assert final == settings
                result = {'case': case, 'rep': rep, 'arm': arm, 'cpu': usage.ru_utime + usage.ru_stime,
                          'user_cpu': usage.ru_utime, 'system_cpu': usage.ru_stime, 'complete_gets': 2001,
                          'foreign_commits': 0 if case == 'warm' else 2001,
                          'body_sha256': canonical[fixture_case], 'distinct_body_hashes': len(hashes),
                          'expected_message_count': 40, 'integrity': 'ok', 'unchanged_populations_and_seed_fk': True,
                          'exit_code': proc.returncode}
                results.append(result)
                (OUT / 'http-results.json').write_text(json.dumps(results, indent=2) + '\n')
                print(label, 'joined CPU', result['cpu'], flush=True)
summary = {}
for case in metadata['cases']:
    medians = {arm: statistics.median(r['cpu'] for r in results if r['case'] == case and r['arm'] == arm) for arm in ['baseline', 'candidate']}
    medians['change_percent'] = 100 * (medians['candidate'] / medians['baseline'] - 1)
    summary[case] = medians
    print(case, medians, flush=True)
(OUT / 'http-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
