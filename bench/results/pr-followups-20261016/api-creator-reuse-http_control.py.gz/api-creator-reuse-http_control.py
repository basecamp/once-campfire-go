"""Matched public bot-API history reads. Test data, processes and cookies stay private."""
import hashlib
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import socket
import sqlite3
import statistics
import subprocess
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SEED = ROOT / '.cache/parity-seeds/default'
CLIENT = ROOT / '.cache/frame-writev-headtohead-20261014/binaries/httprate-mac'
loader = importlib.machinery.SourceFileLoader('upgrade', str(ROOT / 'bin/check-upgrade'))
spec = importlib.util.spec_from_loader(loader.name, loader)
u = importlib.util.module_from_spec(spec)
loader.exec_module(u)
labels = json.loads((SEED / 'labels.json').read_text())
env = {k: v for k, v in os.environ.items() if not k.startswith(('CAMPFIRE_', 'THRUSTER_', 'GO_CPU_', 'GO_ALLOC_', 'PERF_API_')) and k != 'TLS_DOMAIN'}
for line in (ROOT / 'reference/parity/.env.reference').read_text().splitlines():
    if line and not line.startswith('#') and '=' in line:
        k, v = line.split('=', 1)
        env[k] = v
env.update(DISABLE_SSL='true', TARGET_BIND='127.0.0.1', GOMAXPROCS='4')


def backup(source, destination):
    with sqlite3.connect(f'file:{source}?mode=ro', uri=True) as src, sqlite3.connect(destination) as dst:
        src.backup(dst)


def port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def prepare():
    fixtures = OUT / 'fixtures'
    for case in ['repeated', 'unique']:
        directory = fixtures / case
        directory.mkdir(parents=True)
        backup(SEED / 'db/production.sqlite3', directory / 'production.sqlite3')
    builderenv = os.environ | {'PERF_API_FIXTURE_OUT': str(fixtures), 'PERF_API_LABELS': str(SEED / 'labels.json')}
    with (OUT / 'fixture-build.log').open('w') as log:
        subprocess.run([str(OUT / 'baseline.test'), '-test.run', '^TestBuildAPIAuthorProbeFixtures$'],
                       cwd=ROOT, env=builderenv, stdout=log, stderr=subprocess.STDOUT, check=True)


def fetch(base, path, cookie):
    request = urllib.request.Request(base + path, headers={'Cookie': cookie, 'Accept-Encoding': 'identity'})
    with urllib.request.urlopen(request, timeout=10) as response:
        body = response.read()
        assert response.status == 200
        return response.headers, body


if __name__ == '__main__':
    prepare()
    metadata = {'baseline': 'cf06197', 'candidate': 'API creator presentation reused only within a response',
                'machine': os.uname().machine, 'platform': os.uname().sysname,
                'client_sha256': hashlib.sha256(CLIENT.read_bytes()).hexdigest(),
                'source_seed_sha256': hashlib.sha256((SEED / 'db/production.sqlite3').read_bytes()).hexdigest(),
                'binaries': {arm: hashlib.sha256((OUT / (arm + '-mac')).read_bytes()).hexdigest() for arm in ['baseline', 'candidate']},
                'fixtures': ['40 messages, one creator', '40 messages, forty creators'],
                'cpu_scope': 'wait4 joined server CPU includes startup, health/login, exact preflights with author update/restore, 1,000 warm + 4,000 timed full-wire GETs, final validation and shutdown. No profiler/hooks. Local CPU/work evidence only, not native latency/capacity.',
                'orders': [['baseline', 'candidate'], ['candidate', 'baseline'], ['baseline', 'candidate']],
                'repetitions': 3}
    (OUT / 'http-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
    canonical, results = {}, []
    for case in ['repeated', 'unique']:
        fixture = json.loads((OUT / 'fixtures' / case / 'fixture.json').read_text())
        records = fixture['Records']
        ids = [record['ID'] for record in records]
        room = fixture['Room']
        path = f'/rooms/{room}/api-perf/messages'
        for rep, arms in enumerate(metadata['orders'], 1):
            for arm in arms:
                label = f'http-{case}-{arm}-{rep}'
                with tempfile.TemporaryDirectory(prefix=label + '-', dir=OUT) as temp:
                    work = Path(temp)
                    db = work / 'production.sqlite3'
                    backup(OUT / 'fixtures' / case / 'production.sqlite3', db)
                    with sqlite3.connect(db) as conn:
                        users = conn.execute('SELECT count(*) FROM users').fetchone()[0]
                        messages = conn.execute('SELECT count(*) FROM messages').fetchone()[0]
                        total = conn.execute('SELECT count(*) FROM messages WHERE room_id=?', (room,)).fetchone()[0]
                        original_fk = conn.execute('PRAGMA foreign_key_check').fetchall()
                    front, target = port(), port()
                    while target == front:
                        target = port()
                    base = f'http://127.0.0.1:{front}'
                    runenv = env | {'HTTP_PORT': str(front), 'TARGET_PORT': str(target),
                                    'CAMPFIRE_DATABASE_PATH': str(db), 'CAMPFIRE_STORAGE_PATH': str(work / 'storage')}
                    with (OUT / (label + '.log')).open('w') as log:
                        proc = subprocess.Popen([str(OUT / (arm + '-mac')), 'server'], cwd=ROOT, env=runenv, stdout=log, stderr=subprocess.STDOUT)
                        try:
                            for _ in range(300):
                                if proc.poll() is not None:
                                    raise RuntimeError(label + ' exited before readiness')
                                try:
                                    with urllib.request.urlopen(base + '/up', timeout=1) as response:
                                        assert response.read() == u.helper.EXPECTED
                                    break
                                except OSError:
                                    time.sleep(.025)
                            else:
                                raise RuntimeError('startup timeout')
                            cookie = u.login(base, labels)
                            checks = []
                            for query in ['', f'?after={ids[-2]}', f'?after={ids[-1]}', f'?before={ids[20]}']:
                                headers, body = fetch(base, path + query, cookie)
                                values = json.loads(body)
                                assert int(headers['X-Total-Count']) == total
                                if query == '':
                                    assert [v['id'] for v in values] == ids
                                    for value, record in zip(values, records):
                                        assert value['creator']['id'] == record['CreatorID']
                                        assert value['body']['plain_text'].startswith('Performance message')
                                elif query.startswith(f'?after={ids[-2]}'):
                                    assert [v['id'] for v in values] == ids[-1:]
                                elif query.startswith(f'?after={ids[-1]}'):
                                    assert values == []
                                identity = {'body_sha256': hashlib.sha256(body.replace(base.encode(), b'http://benchmark.invalid')).hexdigest(),
                                            'count': headers.get('X-Total-Count'), 'link': headers.get('Link', '').replace(base, 'http://benchmark.invalid')}
                                key = (case, query)
                                if key in canonical:
                                    assert canonical[key] == identity, (label, query, 'complete output changed')
                                else:
                                    canonical[key] = identity
                                checks.append({'query': query, **identity})
                            # A real foreign metadata change must be visible on
                            # the next response; restoration returns identical bytes.
                            author = fixture['Authors'][0]
                            with sqlite3.connect(db) as conn:
                                old = conn.execute('SELECT name,role,updated_at FROM users WHERE id=?', (author,)).fetchone()
                                conn.execute("UPDATE users SET name='Changed API Author',role=2,updated_at='2026-10-16 13:00:00.000000' WHERE id=?", (author,))
                            _, changed = fetch(base, path, cookie)
                            changed_creators = [m['creator'] for m in json.loads(changed) if m['creator']['id'] == author]
                            assert changed_creators and all(c['name'] == 'Changed API Author' and c['role'] == 'bot' and c['avatar_url'].endswith('?v=20261016130000') for c in changed_creators)
                            with sqlite3.connect(db) as conn:
                                conn.execute('UPDATE users SET name=?,role=?,updated_at=? WHERE id=?', (*old, author))
                            _, restored = fetch(base, path, cookie)
                            expected_hash = canonical[(case, '')]['body_sha256']
                            assert hashlib.sha256(restored.replace(base.encode(), b'http://benchmark.invalid')).hexdigest() == expected_hash
                            for duration in [2, 8]:
                                raw = subprocess.check_output([str(CLIENT), '--base', base, '--cookie', cookie,
                                      '--path', path, '--gzip', '0', '--rate', '500', '--conc', '8', '--queue', '8192',
                                      '--pacing', 'timer', '--duration', str(duration)], text=True)
                                sample = json.loads(raw)
                                (OUT / f'{label}-{duration}s.json').write_text(raw)
                                assert sample['ok'] == 500 * duration and sample['errors'] == 0 and sample['unscheduled'] == 0
                                assert sample['statuses'] == {'200': 500 * duration}
                            _, final = fetch(base, path, cookie)
                            assert hashlib.sha256(final.replace(base.encode(), b'http://benchmark.invalid')).hexdigest() == expected_hash
                        finally:
                            if proc.returncode is None:
                                proc.terminate()
                                pid, status, usage = os.wait4(proc.pid, 0)
                                proc.returncode = os.waitstatus_to_exitcode(status)
                            else:
                                raise RuntimeError('server exited before joined accounting')
                        assert pid == proc.pid and proc.returncode == 0, (label, proc.returncode)
                    with sqlite3.connect(db) as conn:
                        assert conn.execute('PRAGMA integrity_check').fetchone() == ('ok',)
                        assert conn.execute('PRAGMA foreign_key_check').fetchall() == original_fk
                        assert conn.execute('SELECT count(*) FROM users').fetchone()[0] == users
                        assert conn.execute('SELECT count(*) FROM messages').fetchone()[0] == messages
                    result = {'case': case, 'rep': rep, 'arm': arm, 'user_cpu': usage.ru_utime, 'system_cpu': usage.ru_stime,
                              'cpu': usage.ru_utime + usage.ru_stime, 'full_wire_gets': 5000, 'preflight': checks,
                              'foreign_author_change_visible_and_restore_exact': True, 'integrity': 'ok',
                              'unchanged_seed_fk': True, 'unchanged_users_messages': True, 'exit_code': proc.returncode}
                    results.append(result)
                    (OUT / 'http-results.json').write_text(json.dumps(results, indent=2) + '\n')
                    print(label, 'joined CPU', result['cpu'], flush=True)
    summary = {}
    for case in ['repeated', 'unique']:
        medians = {arm: statistics.median(r['cpu'] for r in results if r['case'] == case and r['arm'] == arm) for arm in ['baseline', 'candidate']}
        medians['change_percent'] = 100 * (medians['candidate'] / medians['baseline'] - 1)
        summary[case] = medians
        print(case, medians, flush=True)
    (OUT / 'http-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
