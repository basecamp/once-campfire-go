package database

// Temporary profiling probe; not intended for the permanent test suite.
import (
	"context"
	"fmt"
	"path/filepath"
	"testing"
)

func BenchmarkDirectPlaceholdersProbe(b *testing.B) {
	for _, history := range []int{0, 24, 500} {
		b.Run(fmt.Sprint(history), func(b *testing.B) {
			db, err := Open(filepath.Join(b.TempDir(), "probe.sqlite3"), 4)
			if err != nil {
				b.Fatal(err)
			}
			defer db.Close()
			ctx := context.Background()
			owner, err := db.Setup(ctx, "Owner", "owner@test", "digest")
			if err != nil {
				b.Fatal(err)
			}
			stamp := Stamp(db.Now())
			_, err = db.Write.ExecContext(ctx, `WITH RECURSIVE people(n) AS (
SELECT 1 UNION ALL SELECT n+1 FROM people WHERE n<500
) INSERT INTO users(id,name,email_address,role,status,created_at,updated_at)
SELECT ?+n,printf('Person %03d',n),printf('person%d@test',n),0,0,?,? FROM people`, owner.ID, stamp, stamp)
			if err != nil {
				b.Fatal(err)
			}
			if history > 0 {
				_, err = db.Write.ExecContext(ctx, `WITH RECURSIVE directs(n) AS (
SELECT 1 UNION ALL SELECT n+1 FROM directs WHERE n<?
) INSERT INTO rooms(id,type,creator_id,created_at,updated_at) SELECT 1000000+n,'Rooms::Direct',?,?,? FROM directs`, history, owner.ID, stamp, stamp)
				if err != nil {
					b.Fatal(err)
				}
				_, err = db.Write.ExecContext(ctx, `INSERT INTO memberships(user_id,room_id,involvement,created_at,updated_at)
SELECT ?,id,'invisible',?,? FROM rooms WHERE id>1000000
UNION ALL SELECT ?+id-1000000,id,'everything',?,? FROM rooms WHERE id>1000000`, owner.ID, stamp, stamp, owner.ID, stamp, stamp)
				if err != nil {
					b.Fatal(err)
				}
			}
			b.ReportAllocs()
			b.ResetTimer()
			for b.Loop() {
				got, err := db.DirectPlaceholders(ctx, owner.ID)
				count := 0
				if history == 0 {
					count = 19
				}
				if err != nil || len(got) != count {
					b.Fatalf("bad placeholders: %d %v", len(got), err)
				}
			}
		})
	}
}
