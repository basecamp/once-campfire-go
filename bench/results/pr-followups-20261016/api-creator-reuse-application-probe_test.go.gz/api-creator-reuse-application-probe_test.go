package application

// Temporary profiling/fixture input, not a permanent benchmark suite.
import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/basecamp/once-campfire-go/internal/database"
	"github.com/basecamp/once-campfire-go/internal/presentation"
	"github.com/basecamp/once-campfire-go/internal/rails"
)

type apiProbeFixture struct {
	Viewer, Room int64
	Authors      []int64
	Records      []database.Message
}

func fillAPIProbe(t testing.TB, db *database.DB, viewer, room int64, authors, messages int) apiProbeFixture {
	t.Helper()
	ctx := context.Background()
	base := time.Date(2026, 10, 16, 12, 0, 0, 0, time.UTC)
	stamp := database.Stamp(base)
	fixture := apiProbeFixture{Viewer: viewer, Room: room}
	for i := 0; i < 40; i++ {
		result, err := db.Write.ExecContext(ctx, `INSERT INTO users(name,email_address,role,status,created_at,updated_at) VALUES(?,?,?,0,?,?)`, fmt.Sprintf("API Author %02d", i), fmt.Sprintf("api-author-%02d@example.invalid", i), i%3, stamp, stamp)
		if err != nil {
			t.Fatal(err)
		}
		id, err := result.LastInsertId()
		if err != nil {
			t.Fatal(err)
		}
		fixture.Authors = append(fixture.Authors, id)
		_, err = db.Write.ExecContext(ctx, `INSERT INTO memberships(user_id,room_id,involvement,created_at,updated_at) VALUES(?,?,'everything',?,?)`, id, room, stamp, stamp)
		if err != nil {
			t.Fatal(err)
		}
	}
	for i := 0; i < messages; i++ {
		db.Now = func() time.Time { return base.Add(time.Duration(i) * time.Second) }
		body := fmt.Sprintf("<p>Performance message %02d &amp; body</p>", i)
		commit, err := db.CreateMessage(ctx, fixture.Authors[i%authors], room, database.MessageInput{Body: &body})
		if err != nil {
			t.Fatal(err)
		}
		fixture.Records = append(fixture.Records, commit.Message)
	}
	return fixture
}

func BenchmarkAPIAuthorReuseProbe(b *testing.B) {
	for _, scenario := range []struct {
		name              string
		authors, messages int
	}{{"repeated", 1, 40}, {"unique", 40, 40}, {"single", 1, 1}} {
		b.Run(scenario.name, func(b *testing.B) {
			db, err := database.Open(filepath.Join(b.TempDir(), "probe.sqlite3"), 4)
			if err != nil {
				b.Fatal(err)
			}
			defer db.Close()
			ctx := context.Background()
			owner, err := db.Setup(ctx, "Owner", "owner@test", "digest")
			if err != nil {
				b.Fatal(err)
			}
			rooms, err := db.Rooms(ctx, owner.ID)
			if err != nil {
				b.Fatal(err)
			}
			fixture := fillAPIProbe(b, db, owner.ID, rooms[0].ID, scenario.authors, scenario.messages)
			secrets, err := rails.NewSecrets("api-probe-only-secret")
			if err != nil {
				b.Fatal(err)
			}
			renderer, err := presentation.NewRenderer(secrets)
			if err != nil {
				b.Fatal(err)
			}
			queries := MessageQueries{DB: db, Presentation: renderer}
			facts := presentation.Facts{Host: "benchmark.invalid", Origin: "http://benchmark.invalid", Now: db.Now()}
			b.ReportAllocs()
			b.ResetTimer()
			for b.Loop() {
				if scenario.name == "single" {
					message, err := queries.APIRecord(ctx, facts, fixture.Records[0])
					if err != nil || message.Creator.ID != fixture.Authors[0] {
						b.Fatalf("single response changed: %+v %v", message, err)
					}
				} else {
					page, err := queries.APIPage(ctx, facts, owner.ID, fixture.Room, 0, "before", false)
					if err != nil || len(page.Messages) != scenario.messages || page.Count != scenario.messages {
						b.Fatalf("page changed: %+v %v", page, err)
					}
					for i, message := range page.Messages {
						if message.Creator.ID != fixture.Authors[i%scenario.authors] {
							b.Fatal("wrong creator")
						}
					}
				}
			}
		})
	}
}

// Build the two public-listener fixtures before any timed server exists. The
// caller supplies disposable SQLite backups of the shared verification seed.
func TestBuildAPIAuthorProbeFixtures(t *testing.T) {
	out := os.Getenv("PERF_API_FIXTURE_OUT")
	if out == "" {
		return
	}
	raw, err := os.ReadFile(os.Getenv("PERF_API_LABELS"))
	if err != nil {
		t.Fatal(err)
	}
	var labels map[string]json.RawMessage
	if err = json.Unmarshal(raw, &labels); err != nil {
		t.Fatal(err)
	}
	var email string
	var room int64
	if err = json.Unmarshal(labels["emails.david"], &email); err != nil {
		t.Fatal(err)
	}
	if err = json.Unmarshal(labels["rooms.watercooler"], &room); err != nil {
		t.Fatal(err)
	}
	for _, scenario := range []struct {
		name    string
		authors int
	}{{"repeated", 1}, {"unique", 40}} {
		dir := filepath.Join(out, scenario.name)
		db, err := database.Open(filepath.Join(dir, "production.sqlite3"), 4)
		if err != nil {
			t.Fatal(err)
		}
		var viewer int64
		if err = db.Read.QueryRow("SELECT id FROM users WHERE email_address=?", email).Scan(&viewer); err != nil {
			t.Fatal(err)
		}
		fixture := fillAPIProbe(t, db, viewer, room, scenario.authors, 40)
		if err = db.Close(); err != nil {
			t.Fatal(err)
		}
		raw, err = json.Marshal(fixture)
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(dir, "fixture.json"), raw, 0600); err != nil {
			t.Fatal(err)
		}
	}
}
