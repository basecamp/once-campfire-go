"""Cold/foreign-invalidated sidebar controls using complete public HTTP responses."""
import hashlib
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import socket
import sqlite3
import statistics
import subprocess
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SEED = ROOT / '.cache/parity-seeds/default'
loader = importlib.machinery.SourceFileLoader('upgrade', str(ROOT / 'bin/check-upgrade'))
spec = importlib.util.spec_from_loader(loader.name, loader)
u = importlib.util.module_from_spec(spec)
loader.exec_module(u)
labels = json.loads((SEED / 'labels.json').read_text())
env = {k: v for k, v in os.environ.items() if not k.startswith(('CAMPFIRE_', 'THRUSTER_', 'GO_CPU_', 'GO_ALLOC_')) and k != 'TLS_DOMAIN'}
for line in (ROOT / 'reference/parity/.env.reference').read_text().splitlines():
    if line and not line.startswith('#') and '=' in line:
        k, v = line.split('=', 1)
        env[k] = v
        
env.update(DISABLE_SSL='true', TARGET_BIND='127.0.0.1', GOMAXPROCS='4')


def port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


results = []
metadata = {'baseline': 'e1be505', 'candidate': 'LIMIT 19 in placeholder exclusions only',
            'machine': os.uname().machine, 'platform': os.uname().sysname,
            'binaries': {arm: hashlib.sha256((OUT / (arm + '-mac')).read_bytes()).hexdigest()
                         for arm in ['baseline', 'placeholders']},
            'seed_sha256': hashlib.sha256((SEED / 'db/production.sqlite3').read_bytes()).hexdigest(),
            'fixtures': ['shared 10-user seed', 'same seed extended to 501 users with hidden one-to-one direct history'],
            'cpu_scope': 'Joined wait4 server CPU includes startup, health/login, preflight, 1,000 warm and 5,000 measured complete sidebar GETs, and shutdown. Client foreign commits are excluded. No profiler/hooks or competing task checks/builds/agents. Local work evidence only.',
            'cache_policy': 'Production defaults. An actual independent SQLite commit changes an ignored JSON settings key before each GET. This exercises cold/invalidated reads, not repeated warm-cache hits.',
            'orders': [['baseline', 'placeholders'], ['placeholders', 'baseline'], ['baseline', 'placeholders']]}
(OUT / 'sidebar-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
canonical = {}
for size in [10, 501]:
    for rep, arms in enumerate(metadata['orders'], 1):
        for arm in arms:
            label = f'sidebar-{size}-{arm}-{rep}'
            with tempfile.TemporaryDirectory(prefix=label + '-', dir=OUT) as temp:
                work = Path(temp)
                db = work / 'production.sqlite3'
                with sqlite3.connect(f'file:{SEED}/db/production.sqlite3?mode=ro', uri=True) as source, sqlite3.connect(db) as target:
                    source.backup(target)
                with sqlite3.connect(db) as conn:
                    viewer = conn.execute('SELECT id FROM users WHERE email_address=?', (labels['emails.david'],)).fetchone()[0]
                    stamp = '2026-10-16 00:00:00.000000'
                    room_id = conn.execute('SELECT max(id) FROM rooms').fetchone()[0]
                    for n in range(size - 10):
                        person = conn.execute('INSERT INTO users(name,email_address,role,status,created_at,updated_at) VALUES(?,?,0,0,?,?)',
                                              (f'Person {n:03d}', f'bounded-{n}@example.invalid', stamp, stamp)).lastrowid
                        direct = room_id + n + 1
                        conn.execute("INSERT INTO rooms(id,type,creator_id,created_at,updated_at) VALUES(?,'Rooms::Direct',?,?,?)", (direct, viewer, stamp, stamp))
                        conn.executemany('INSERT INTO memberships(user_id,room_id,involvement,created_at,updated_at) VALUES(?,?,?,?,?)',
                                         [(viewer, direct, 'invisible', stamp, stamp), (person, direct, 'everything', stamp, stamp)])
                    original_settings = conn.execute('SELECT settings FROM accounts LIMIT 1').fetchone()[0]
                    expected_users = conn.execute('SELECT count(*) FROM users').fetchone()[0]
                    before_fk = conn.execute('PRAGMA foreign_key_check').fetchall()
                    before_messages = conn.execute('SELECT count(*) FROM messages').fetchone()[0]
                front, target = port(), port()
                while target == front:
                    target = port()
                base = f'http://127.0.0.1:{front}'
                runenv = env | {'HTTP_PORT': str(front), 'TARGET_PORT': str(target),
                                'CAMPFIRE_DATABASE_PATH': str(db), 'CAMPFIRE_STORAGE_PATH': str(work / 'storage')}
                with (OUT / (label + '.log')).open('w') as log:
                    proc = subprocess.Popen([str(OUT / (arm + '-mac')), 'server'], cwd=ROOT, env=runenv, stdout=log, stderr=subprocess.STDOUT)
                    try:
                        for _ in range(300):
                            if proc.poll() is not None:
                                raise RuntimeError(label + ' exited before readiness')
                            try:
                                with urllib.request.urlopen(base + '/up', timeout=1) as response:
                                    assert response.read() == u.helper.EXPECTED
                                break
                            except OSError:
                                time.sleep(.025)
                        else:
                            raise RuntimeError('startup timeout')
                        cookie = u.login(base, labels)
                        client = __import__('http.client', fromlist=['HTTPConnection']).HTTPConnection('127.0.0.1', front, timeout=10)
                        headers = {'Cookie': cookie, 'Accept-Encoding': 'identity'}
                        foreign = sqlite3.connect(db, isolation_level=None)
                        hashes = set()
                        for sequence in range(6001):
                            # Unknown settings keys do not alter rendered inputs;
                            # the commit must still invalidate foreign-aware caches.
                            foreign.execute("UPDATE accounts SET settings=json_set(coalesce(settings,'{}'),'$.benchmark_epoch',?)", (sequence,))
                            client.request('GET', '/users/me/sidebar', headers=headers)
                            response = client.getresponse()
                            body = response.read()
                            assert response.status == 200 and b'data-room-id=' in body
                            digest = hashlib.sha256(body.replace(base.encode(), b'http://benchmark.invalid')).hexdigest()
                            hashes.add(digest)
                            if size not in canonical:
                                canonical[size] = digest
                            assert canonical[size] == digest, (label, sequence, 'complete sidebar changed')
                        client.close()
                        foreign.close()
                    finally:
                        if proc.returncode is None:
                            proc.terminate()
                            pid, status, usage = os.wait4(proc.pid, 0)
                            proc.returncode = os.waitstatus_to_exitcode(status)
                        else:
                            raise RuntimeError('server exited before joined accounting')
                    assert pid == proc.pid and proc.returncode == 0, (label, proc.returncode)
                with sqlite3.connect(db) as conn:
                    assert conn.execute('PRAGMA integrity_check').fetchone() == ('ok',)
                    assert conn.execute('PRAGMA foreign_key_check').fetchall() == before_fk
                    assert conn.execute('SELECT count(*) FROM users').fetchone()[0] == expected_users == size
                    assert conn.execute('SELECT count(*) FROM messages').fetchone()[0] == before_messages
                    settings = json.loads(conn.execute('SELECT settings FROM accounts LIMIT 1').fetchone()[0])
                    assert settings.pop('benchmark_epoch') == 6000
                    assert settings == json.loads(original_settings or '{}')
                result = {'size': size, 'rep': rep, 'arm': arm, 'user_cpu': usage.ru_utime, 'system_cpu': usage.ru_stime,
                          'cpu': usage.ru_utime + usage.ru_stime, 'complete_gets': 6001, 'foreign_commits': 6001,
                          'canonical_sha256': canonical[size], 'distinct_body_hashes': len(hashes),
                          'integrity': 'ok', 'unchanged_seed_fk': True, 'exit_code': proc.returncode}
                results.append(result)
                (OUT / 'sidebar-results.json').write_text(json.dumps(results, indent=2) + '\n')
                print(label, 'joined CPU', result['cpu'], flush=True)
for size in [10, 501]:
    medians = {arm: statistics.median(r['cpu'] for r in results if r['size'] == size and r['arm'] == arm)
               for arm in ['baseline', 'placeholders']}
    print('size', size, medians, 'candidate CPU change %', 100 * (medians['placeholders'] / medians['baseline'] - 1), flush=True)
