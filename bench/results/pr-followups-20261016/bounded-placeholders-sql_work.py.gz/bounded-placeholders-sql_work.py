"""Count SQLite VM steps, not Python wall time; compare exact SQL/results."""
import json
from pathlib import Path
import sqlite3
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
source = ROOT / '.cache/perf-bounded-queries-20261016'

def query(path):
    text = path.read_text()
    return 'WITH excluded AS MATERIALIZED (' + text.split('WITH excluded AS MATERIALIZED (', 1)[1].split('`, user, user)', 1)[0]

queries = {'baseline': query(ROOT / 'internal/database/accounts.go'),
           'candidate': query(source / 'internal/database/accounts.go')}
results = {'sqlite_version': sqlite3.sqlite_version,
           'limitation': 'Python SQLite VM-step/plan evidence only; Go query and full-application work are measured separately with the actual embedded Go driver.',
           'queries': queries, 'fixtures': []}
for history in [0, 24, 500]:
    db = sqlite3.connect(':memory:')
    db.executescript((ROOT / 'internal/database/schema.sql').read_text())
    stamp = '2026-10-16 00:00:00.000000'
    db.executemany('INSERT INTO users(id,name,status,role,created_at,updated_at) VALUES(?,?,0,0,?,?)',
                   [(i, f'Person {i:03d}', stamp, stamp) for i in range(1, 502)])
    for n in range(history):
        room = n + 1
        db.execute("INSERT INTO rooms(id,type,creator_id,created_at,updated_at) VALUES(?,'Rooms::Direct',1,?,?)", (room, stamp, stamp))
        db.executemany('INSERT INTO memberships(user_id,room_id,involvement,created_at,updated_at) VALUES(?,?,?,?,?)',
                       [(1, room, 'invisible', stamp, stamp), (n + 2, room, 'everything', stamp, stamp)])
    samples = {}
    expected = None
    for arm, sql in queries.items():
        warm = db.execute(sql, (1, 1)).fetchall()
        steps = [0]
        def progress():
            steps[0] += 1
            return 0
        db.set_progress_handler(progress, 1)
        rows = db.execute(sql, (1, 1)).fetchall()
        db.set_progress_handler(None, 0)
        if expected is None:
            expected = rows
        assert rows == expected == warm
        samples[arm] = {'vm_steps': steps[0], 'result_count': len(rows),
                        'plan': db.execute('EXPLAIN QUERY PLAN ' + sql, (1, 1)).fetchall()}
    results['fixtures'].append({'direct_history': history, 'samples': samples})
    print(history, {arm: s['vm_steps'] for arm, s in samples.items()}, flush=True)
    db.close()
(OUT / 'sql-work.json').write_text(json.dumps(results, indent=2) + '\n')
